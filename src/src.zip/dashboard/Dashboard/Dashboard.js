import React from 'react';

const Dashboard = () => {
  return (
    <>
      <div className='h-96 text-center'>
        <h2 className='pt-48 text-2xl font-medium text-[#f06425]'>Welcome to Dashboard!</h2>
      </div>
    </>
  );
};

export default Dashboard;